﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MVCMovie.Data;
using System;
using System.Linq;

namespace MvcMovie.Models;

public static class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new MVCMovieContext(
            serviceProvider.GetRequiredService<
                DbContextOptions<MVCMovieContext>>()))
        {
            // Look for any movies.
            if (context.Movie.Any())
            {
                return;   // DB has been seeded
            }
            context.Movie.AddRange(
                new Movie
                {
                    Title = "Metropolis",
                    ReleaseDate = DateTime.Parse("1927-1-10"),
                    Genre = "Science Fiction",
                    Price = 7.99M,
                    Image = "https://www.moma.org/media/W1siZiIsIjE2OTkwNCJdLFsicCIsImNvbnZlcnQiLCItcXVhbGl0eSA5MCAtcmVzaXplIDIwMDB4MjAwMFx1MDAzZSJdXQ.jpg"
                },
                new Movie
                {
                    Title = "Tron",
                    ReleaseDate = DateTime.Parse("1984-7-09"),
                    Genre = "Science Fiction",
                    Price = 20.10M
                },
                new Movie
                {
                    Title = "American Psycho",
                    ReleaseDate = DateTime.Parse("2000-4-14"),
                    Genre = "Horror",
                    Price = 1.90M
                },
                new Movie
                {
                    Title = "Blade Runner",
                    ReleaseDate = DateTime.Parse("1982-6-25"),
                    Genre = "Science Fiction",
                    Price = 20.49M
                }
            );
            context.SaveChanges();
        }
    }
}